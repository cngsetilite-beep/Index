<?php
session_start();

// Check if user is logged in, else redirect back
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: ctestpage.php');
    exit;
}

$email = $_SESSION['email'] ?? 'User';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Thank You - Аррlе Account</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen,
                Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;
            background-color: #fff;
            color: #333;
            text-align: center;
            padding: 50px;
        }
        .thank-you-message {
            font-size: 1.5rem;
            margin-top: 20px;
        }
        .account-logo {
            width: 180px;
            height: 180px;
            margin-bottom: 24px;
        }
        .success-icon {
            width: 100px;
            height: 100px;
            margin-bottom: 20px;
        }
        @media (max-width: 768px) {
            .account-logo {
                width: 140px;
                height: 140px;
            }
            .thank-you-message {
                font-size: 1.2rem;
            }
        }
    </style>
</head>
<body>
    <img src="aicon.png" alt="Apple Logo" class="account-logo">
    <h1>Thank You!</h1>
    <p class="thank-you-message">Your details have been successfully entered. Welcome, <?php echo htmlspecialchars($email); ?>!</p>
   
</body>
</html>
