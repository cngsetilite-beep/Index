
<?php
require 'config.php';

if (!isset($_GET['token'])) {
    $token = generateToken();
    header("Location: /secure/$token");
    exit;
}

if (!validateToken($_GET['token'])) {
    die("Invalid or Expired Session");
}

define('ACCESS_ALLOWED', true);
include 'index.php';
?>
