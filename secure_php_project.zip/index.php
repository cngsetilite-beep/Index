
<?php
if (!defined('ACCESS_ALLOWED')) {
    die("Direct Access Not Allowed");
}

// Sensitive logic here (server-side only)
$data = [
    "status" => "success",
    "message" => "Secure Content Loaded Successfully",
    "time" => date("Y-m-d H:i:s")
];

header('Content-Type: application/json');
echo json_encode($data);
exit;
?>
