
<?php
session_start();

define('SECRET_KEY', 'UltraSecureKey_2026_XYZ');
define('TOKEN_EXPIRY', 60);

function generateToken() {
    $random = bin2hex(random_bytes(32));
    $_SESSION['secure_token'] = $random;
    $_SESSION['token_time'] = time();
    $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
    $_SESSION['agent'] = $_SERVER['HTTP_USER_AGENT'];
    return $random;
}

function validateToken($token) {

    if (!isset($_SESSION['secure_token'], $_SESSION['token_time'], $_SESSION['ip'], $_SESSION['agent'])) {
        return false;
    }

    if (time() - $_SESSION['token_time'] > TOKEN_EXPIRY) {
        session_destroy();
        return false;
    }

    if ($_SESSION['ip'] !== $_SERVER['REMOTE_ADDR']) {
        return false;
    }

    if ($_SESSION['agent'] !== $_SERVER['HTTP_USER_AGENT']) {
        return false;
    }

    return hash_equals($_SESSION['secure_token'], $token);
}
?>
