<?php
$verified = false;
if (isset($_GET['verify'])) {
    $verified = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Verifying Your Request</title>

<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #ffffff;
}
.overlay {
    position: fixed;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
}
.popup {
    width: 360px;
    padding: 30px;
    text-align: center;
    border-radius: 10px;
    box-shadow: 0 0 25px rgba(0,0,0,0.12);
}
.logo {
    width: 60px;
    margin-bottom: 15px;
}
h2 {
    font-size: 22px;
    margin-bottom: 15px;
}
.user-box {
    display: inline-block;
    padding: 8px 14px;
    border: 1px solid #ddd;
    border-radius: 20px;
    font-size: 14px;
    margin-bottom: 15px;
}
.user-box a {
    color: #1da1f2;
    text-decoration: none;
    margin-left: 8px;
}
.text {
    color: #555;
    font-size: 14px;
    margin-bottom: 20px;
}
.loader {
    width: 26px;
    height: 26px;
    border: 3px solid #ddd;
    border-top: 3px solid #000;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: auto;
}
@keyframes spin {
    to { transform: rotate(360deg); }
}
.success {
    font-size: 22px;
    color: green;
}
</style>
</head>
<body>
<div class="overlay">
<div class="popup">
<?php if (!$verified) { ?>
<img src="https://upload.wikimedia.org/wikipedia/en/a/ad/Snapchat_logo.svg" class="logo">
<h2>Verifying Your Request</h2>
<div class="user-box">
Snapchat user <a href="#">Not you?</a>
</div>
<p class="text">Please wait while we perform<br>security verifications.</p>
<div class="loader"></div>
<?php } else { ?>
<div class="success">✅ Verification Completed</div>
<p>You have been successfully verified.</p>
<?php } ?>
</div>
</div>
<?php if (!$verified) { ?>
<script>
setTimeout(() => {
    window.location.href = "?verify=1";
}, 5000);
</script>
<?php } ?>
</body>
</html>
